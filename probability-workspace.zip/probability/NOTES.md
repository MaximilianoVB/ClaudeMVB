# Notes

- Grading: "1.1" = Irish First Class Honours (70%+). The target is high, not a pass.
- Level: starting from zero (as of 2026-11-24).
- Time: 14 days. Plan ~1 lesson/day plus a past-exam block. Spaced review: re-quiz day N-1 and day N-3 topics at the start of each lesson.
- Wants all MIT versions used as sources, not only one offering.
- Exam topics: received as photos of the RES.6-012 Part I page (L1–L13). Unconfirmed whether Part II is also examined.
- Delivery: claude.ai artifact (one course hub artifact holding all lessons + reference). Learner pastes files into github.com/MaximilianoVB/ClaudeMVB under `probability/`.

## 14-day plan (exam scope = RES.6-012 Part I, L1–L13)
1. L1 Probability models & axioms (+ math background)
2. L2 Conditioning & Bayes' rule
3. L3 Independence
4. L4 Counting
5. L5 Discrete RVs I (PMFs, expectation)
6. L6 Discrete RVs II (variance, conditioning, geometric)
7. L7 Discrete RVs III (joint PMFs, independence)
8. L8 Continuous RVs I (PDFs, CDFs, exponential, normal)
9. L9 Continuous RVs II (conditioning, joint PDFs)
10. L10 Continuous RVs III (conditional PDFs, continuous Bayes)
11. L11 Derived distributions
12. L12 Sums of independent RVs (convolution), covariance, correlation
13. L13 Conditional expectation & variance revisited, random sums
14. Timed mock exam (past 6.041 quizzes on this material)
