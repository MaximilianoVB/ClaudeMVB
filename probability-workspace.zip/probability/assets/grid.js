// Reusable outcome grid for two rolls of an n-sided die (Tsitsiklis's tetrahedral-die model).
// OutcomeGrid.mount(el, {
//   n: 4,
//   tasks: [{ prompt: "Select the event ...", test: function (x, y) { return ... } }, ...]
// })
// The learner clicks outcomes (x = first roll, y = second roll) to build an event,
// then presses Check. Feedback names missing and extra outcomes.
// Later lessons reuse it for conditioning (restrict the universe to an event B).
window.OutcomeGrid = {
  mount: function (root, opts) {
    var n = opts.n || 4, tasks = opts.tasks, t = 0, sel = {};
    root.innerHTML =
      '<div class="grid-wrap"><div class="ogrid" role="group" aria-label="Outcomes (first roll, second roll)"></div>' +
      '<div class="grid-side"><p class="task"></p><p class="count"></p>' +
      '<div style="display:flex;gap:.5rem;flex-wrap:wrap"><button type="button" class="primary chk">Check</button>' +
      '<button type="button" class="clr">Clear</button><button type="button" class="nxt" hidden>Next task</button></div>' +
      '<p class="fb" aria-live="polite"></p></div></div>';
    var g = root.querySelector(".ogrid"), q = function (s) { return root.querySelector(s); };
    g.style.gridTemplateColumns = "1.6rem repeat(" + n + ", 2.6rem)";
    // Rows: y from n down to 1, so the picture matches an x-y plot.
    for (var y = n; y >= 1; y--) {
      var ax = document.createElement("span"); ax.className = "axis"; ax.textContent = y; g.appendChild(ax);
      for (var x = 1; x <= n; x++) {
        var c = document.createElement("button");
        c.type = "button"; c.className = "cell"; c.dataset.k = x + "," + y;
        c.textContent = "(" + x + "," + y + ")";
        c.setAttribute("aria-pressed", "false");
        c.addEventListener("click", function () {
          var k = this.dataset.k; sel[k] = !sel[k];
          this.classList.toggle("on", sel[k]); this.setAttribute("aria-pressed", String(!!sel[k]));
          upd();
        });
        g.appendChild(c);
      }
    }
    g.appendChild(document.createElement("span"));
    for (var x2 = 1; x2 <= n; x2++) { var a2 = document.createElement("span"); a2.className = "axis"; a2.textContent = x2; g.appendChild(a2); }

    function count() { return Object.keys(sel).filter(function (k) { return sel[k]; }).length; }
    function upd() { q(".count").textContent = count() + " of " + n * n + " outcomes selected"; }
    function load() {
      sel = {}; root.querySelectorAll(".cell").forEach(function (c) { c.classList.remove("on"); c.setAttribute("aria-pressed", "false"); });
      q(".task").innerHTML = "<b>Task " + (t + 1) + " of " + tasks.length + ".</b> " + tasks[t].prompt;
      q(".fb").textContent = ""; q(".nxt").hidden = true; upd();
    }
    q(".clr").addEventListener("click", load);
    q(".nxt").addEventListener("click", function () { t++; load(); });
    q(".chk").addEventListener("click", function () {
      var miss = 0, extra = 0, size = 0;
      for (var x = 1; x <= n; x++) for (var y = 1; y <= n; y++) {
        var want = tasks[t].test(x, y), has = !!sel[x + "," + y];
        if (want) size++;
        if (want && !has) miss++;
        if (!want && has) extra++;
      }
      var fb = q(".fb");
      if (!miss && !extra) {
        fb.innerHTML = '<b style="color:var(--good)">Correct.</b> ' + size + " outcomes, so P = " + size + "/" + n * n + "." + (tasks[t].after ? " " + tasks[t].after : "");
        if (t < tasks.length - 1) q(".nxt").hidden = false;
      } else {
        fb.innerHTML = '<b style="color:var(--bad)">Not yet.</b> ' +
          (miss ? miss + " outcome" + (miss > 1 ? "s" : "") + " missing. " : "") +
          (extra ? extra + " selected outcome" + (extra > 1 ? "s don't" : " doesn't") + " belong." : "");
      }
    });
    load();
  }
};
