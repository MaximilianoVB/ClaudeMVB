// Reusable multiple-choice quiz.
// Markup: <div class="exercise quiz" data-correct="2" data-explain="Why...">
//   <p class="label">Q1</p><p>Question</p>
//   <div class="options"><button>..</button>...</div>
// </div>
// data-correct is the 0-based index of the right option. Feedback appears on the first click.
// A <p class="score" data-quiz-score></p> anywhere on the page shows the running tally.
(function () {
  var answered = 0, right = 0, total = 0;
  function tally() {
    document.querySelectorAll("[data-quiz-score]").forEach(function (el) {
      el.textContent = right + " / " + total + " correct" + (answered < total ? "  (" + (total - answered) + " left)" : "");
    });
  }
  document.querySelectorAll(".quiz").forEach(function (q) {
    total++;
    var correct = parseInt(q.dataset.correct, 10);
    var buttons = q.querySelectorAll(".options button");
    var fb = document.createElement("p");
    fb.className = "feedback";
    fb.setAttribute("aria-live", "polite");
    q.appendChild(fb);
    buttons.forEach(function (b, i) {
      b.type = "button";
      b.addEventListener("click", function () {
        if (q.dataset.done) return;
        q.dataset.done = "1";
        answered++;
        var ok = i === correct;
        if (ok) right++;
        b.classList.add(ok ? "right" : "wrong");
        buttons[correct].classList.add("right");
        fb.className = "feedback " + (ok ? "right" : "wrong");
        fb.innerHTML = "<b>" + (ok ? "Correct." : "Not quite.") + "</b> " + (q.dataset.explain || "");
        tally();
      });
    });
  });
  tally();
})();
