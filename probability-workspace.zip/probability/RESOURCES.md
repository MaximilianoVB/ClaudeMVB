# Probability Resources

## Knowledge

- [RES.6-012 Introduction to Probability, Spring 2018 (Tsitsiklis & Jaillet)](https://ocw.mit.edu/courses/res-6-012-introduction-to-probability-spring-2018/)
  The cleanest modern version: short lecture videos, slides, and solved problems for Part I (fundamentals) and Part II (inference, limit theorems). Use for: the **primary video** for each lesson.
- [6.041SC Probabilistic Systems Analysis, Fall 2013 (OCW Scholar)](https://ocw.mit.edu/courses/6-041sc-probabilistic-systems-analysis-and-applied-probability-fall-2013/)
  Full Fall 2010 lectures by Tsitsiklis plus 51 TA recitation and tutorial videos, problem sets, and exams with solutions. Use for: worked recitation problems and **past exams**.
- [6.041 Fall 2010](https://ocw.mit.edu/courses/6-041-probabilistic-systems-analysis-and-applied-probability-fall-2010/)
  The original lecture recordings with readings mapped to textbook sections. Use for: the reading list per lecture.
- [6.041 Spring 2006](https://ocw.mit.edu/courses/6-041-probabilistic-systems-analysis-and-applied-probability-spring-2006/)
  Problem sets, recitations, and quizzes with solutions. Use for: a second bank of exam-style problems.
- [6.041/6.431 Spring 2005, DSpace archive](https://dspace.mit.edu/handle/1721.1/70858)
  Bertsekas, Tsitsiklis & Médard. Use for: a third bank of quizzes and finals for mock exams.
- Book: Bertsekas & Tsitsiklis, *Introduction to Probability*, 2nd ed. (Athena Scientific, 2008)
  The course textbook, with end-of-chapter problems and solutions online. Use for: reading after each lesson and drills.

## Wisdom (Communities)

- [Math Stack Exchange, `probability` tag](https://math.stackexchange.com/questions/tagged/probability)
  Heavily moderated. Use for: checking an alternative solution or a "why is my answer wrong" question.
- Classmates or a study group for your actual exam
  Use for: swapping past papers and timing mock exams together.

## Gaps
- The learner's own exam topic list and past papers (photos coming)
- ocw.mit.edu is blocked from this cloud session, so slide contents haven't been fetched directly. Lessons follow the standard Bertsekas & Tsitsiklis treatment and link to the official pages.
