# Mission: Probability (MIT 6.041 / RES.6-012, Tsitsiklis)

## Why
Get a 1.1 (First Class Honours, 70%+, on the Irish scale) on a probability exam in two weeks (exam around 2026-12-08), starting from zero.

## Success looks like
- Solves exam-style problems for every examinable topic without notes, at exam speed
- Picks the right tool on sight (counting vs. conditioning vs. total probability vs. Bayes vs. a named distribution vs. expectation tricks)
- Scores 70%+ on a timed mock exam built from past MIT 6.041 quizzes and finals

## Constraints
- 14 days, starting from zero, so every lesson has to pay off on the exam
- Exam scope (from the learner's photos, 2026-11-24): RES.6-012 Part I "The Fundamentals", Lectures 1–13 plus the L1 math-background supplement
- Sources: every MIT/Tsitsiklis version (6.041 2005/2006/2010, 6.041SC 2013, RES.6-012 2018) plus Bertsekas & Tsitsiklis
- Lessons are delivered as claude.ai artifacts; the learner pastes files into the repo by hand (no GitHub connection)

## Out of scope
- Measure-theoretic probability (6.436-level rigor)
- RES.6-012 Part II (inference, Bernoulli/Poisson processes, Markov chains, limit theorems), unless the learner says otherwise
